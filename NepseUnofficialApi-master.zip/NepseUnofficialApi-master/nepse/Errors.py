class NepseInvalidServerResponse(Exception):
    pass


class NepseInvalidClientRequest(Exception):
    pass


class NepseNetworkError(Exception):
    pass


class NepseTokenExpired(Exception):
    pass
